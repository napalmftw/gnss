package com.pixel9.gnssspeedometer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

class MainActivity : AppCompatActivity(), LocationListener {

    companion object {
        private const val REQ_LOCATION_PERMISSION = 1001
        private const val PREFS_NAME = "pixel9_gnss_hud_prefs"
    }

    enum class SpeedUnit(val label: String, val factorFromMs: Double) {
        MPH("MPH", 2.2369362920544),
        KMH("KM/H", 3.6),
        KNOTS("KTS", 1.9438444924406),
        MS("M/S", 1.0)
    }

    enum class AltitudeUnit(val label: String, val factorFromM: Double) {
        FEET("FT", 3.280839895),
        METERS("M", 1.0)
    }

    enum class HeadingFormat(val badge: String) {
        DEG_AND_CARD("DEG + CARD"),
        DEG_ONLY("DEG ONLY"),
        CARD_ONLY("CARDINAL")
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var locationManager: LocationManager

    // User preferences
    private var speedUnit: SpeedUnit = SpeedUnit.MPH
    private var altitudeUnit: AltitudeUnit = AltitudeUnit.FEET
    private var headingFormat: HeadingFormat = HeadingFormat.DEG_AND_CARD
    private var showDecimalSpeed: Boolean = false
    private var stationaryFilter: Boolean = true
    private var keepScreenOn: Boolean = true
    private var mirrorHud: Boolean = false
    private var accentColor: Int = Color.parseColor("#00FF66")

    // Live GNSS Telemetry (SI units internally)
    private var currentSpeedMs: Double = 0.0
    private var maxSpeedMs: Double = 0.0
    private var speedAccuracyMs: Float? = null
    private var currentHeadingDeg: Float? = null
    private var lastLockedHeadingDeg: Float? = null
    private var currentAltitudeM: Double? = null
    private var isMslAltitude: Boolean = false
    private var minAltitudeM: Double? = null
    private var maxAltitudeM: Double? = null
    private var verticalAccM: Float? = null
    private var horizontalAccM: Float? = null
    private var satellitesUsed: Int = 0
    private var satellitesInView: Int = 0
    private var hasGnssFix: Boolean = false
    private var prevLocation: Location? = null

    // Demo Simulator
    private var demoMode: Boolean = false
    private var demoPhase: Double = 0.0
    private val mainHandler = Handler(Looper.getMainLooper())
    private val demoRunnable = object : Runnable {
        override fun run() {
            if (!demoMode) return
            demoPhase += 0.08
            currentSpeedMs = 28.5 + sin(demoPhase * 0.7) * 6.0 + cos(demoPhase * 1.8) * 1.5
            if (currentSpeedMs > maxSpeedMs) maxSpeedMs = currentSpeedMs
            currentHeadingDeg = ((285.0 + sin(demoPhase * 0.35) * 28.0 + 360.0) % 360.0).toFloat()
            lastLockedHeadingDeg = currentHeadingDeg
            currentAltitudeM = 224.0 + sin(demoPhase * 0.2) * 14.0
            isMslAltitude = true
            minAltitudeM = minAltitudeM?.let { minOf(it, currentAltitudeM!!) } ?: currentAltitudeM
            maxAltitudeM = maxAltitudeM?.let { maxOf(it, currentAltitudeM!!) } ?: currentAltitudeM
            horizontalAccM = 2.8f
            verticalAccM = 4.1f
            satellitesUsed = 22
            satellitesInView = 31
            hasGnssFix = true
            renderTelemetry()
            mainHandler.postDelayed(this, 250L)
        }
    }

    // GNSS Satellite status callback
    private val gnssStatusCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var used = 0
            val total = status.satelliteCount
            for (i in 0 until total) {
                if (status.usedInFix(i)) used++
            }
            satellitesUsed = used
            satellitesInView = total
            renderTelemetry()
        }
    }

    // UI Views
    private lateinit var rootContainer: LinearLayout
    private lateinit var bodyContainer: LinearLayout
    private lateinit var secondaryContainer: LinearLayout

    private lateinit var tvStatusPill: TextView
    private lateinit var tvSatsPill: TextView
    private lateinit var tvWakePill: TextView
    private lateinit var tvDemoPill: TextView
    private lateinit var tvHudMirrorPill: TextView
    private lateinit var tvMenuPill: TextView

    private lateinit var cardSpeed: LinearLayout
    private lateinit var tvSpeedHeaderBadge: TextView
    private lateinit var tvSpeedDigits: TextView
    private lateinit var tvSpeedUnit: TextView
    private lateinit var tvDecimalBtn: TextView
    private lateinit var tvMaxSpeed: TextView
    private lateinit var tvResetMaxBtn: TextView

    private lateinit var cardHeading: LinearLayout
    private lateinit var tvHeadingFormatBadge: TextView
    private lateinit var tvHeadingDigits: TextView
    private lateinit var tvHeadingCardinal: TextView
    private lateinit var tvHeadingSubtext: TextView
    private lateinit var compassView: CompassRoseView

    private lateinit var cardAltitude: LinearLayout
    private lateinit var tvAltUnitBadge: TextView
    private lateinit var tvAltitudeDigits: TextView
    private lateinit var tvAltitudeUnit: TextView
    private lateinit var tvAltitudeSubtext: TextView
    private lateinit var tvAltitudeMinMax: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        loadPreferences()

        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        configureWindow()
        buildOledHierarchy()
        applyOrientationLayout(resources.configuration.orientation)
        renderTelemetry()
        ensureLocationPermissionAndStart()
    }

    private fun configureWindow() {
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        updateKeepScreenOnFlag()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
        }
    }

    private fun updateKeepScreenOnFlag() {
        if (keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun buildOledHierarchy() {
        val monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        val sansBold = Typeface.create("sans-serif-medium", Typeface.BOLD)

        rootContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            val pad = dp(14)
            setPadding(pad, dp(16), pad, dp(14))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 1. TOP STATUS & CONTROL BAR
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        }

        tvStatusPill = makePillButton("GNSS ACQUIRING", true) {
            if (demoMode) {
                toggleDemoMode(false)
            } else {
                ensureLocationPermissionAndStart()
            }
        }
        tvSatsPill = makePillButton("SATS: 0/0", false) {
            Toast.makeText(this, "Satellites Used in Fix / Total in View", Toast.LENGTH_SHORT).show()
        }
        tvWakePill = makePillButton("ALWAYS ON", keepScreenOn) {
            keepScreenOn = !keepScreenOn
            updateKeepScreenOnFlag()
            savePreferences()
            renderTelemetry()
        }
        tvDemoPill = makePillButton("DEMO", demoMode) {
            toggleDemoMode(!demoMode)
        }
        tvHudMirrorPill = makePillButton("HUD", mirrorHud) {
            mirrorHud = !mirrorHud
            rootContainer.scaleX = if (mirrorHud) -1f else 1f
            renderTelemetry()
        }
        tvMenuPill = makePillButton("MENU", false) {
            showSettingsDialog()
        }

        val leftBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            addView(tvStatusPill, pillMargin())
            addView(tvSatsPill, pillMargin())
            addView(tvWakePill, pillMargin())
        }

        val rightBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(tvDemoPill, pillMargin())
            addView(tvHudMirrorPill, pillMargin())
            addView(tvMenuPill)
        }

        topBar.addView(leftBar)
        topBar.addView(rightBar)
        rootContainer.addView(topBar)

        // 2. BODY CONTAINER (Adapts between Portrait and Landscape)
        bodyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        // --- PRIMARY SPEED CARD (LARGE DIGITS IN CENTER) ---
        cardSpeed = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = makeCardDrawable()
            val pad = dp(18)
            setPadding(pad, dp(16), pad, dp(16))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                cycleSpeedUnit()
            }
        }

        val speedTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val tvSpeedTitle = TextView(this).apply {
            text = "GNSS GROUND SPEED"
            setTextColor(Color.parseColor("#888888"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = sansBold
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        tvSpeedHeaderBadge = TextView(this).apply {
            text = "TAP TO CYCLE UNIT"
            setTextColor(Color.parseColor("#777777"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = monoBold
        }
        speedTopRow.addView(tvSpeedTitle)
        speedTopRow.addView(tvSpeedHeaderBadge)

        tvSpeedDigits = TextView(this).apply {
            text = "0"
            setTextColor(accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 118f)
            typeface = monoBold
            gravity = Gravity.CENTER
            includeFontPadding = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val speedUnitRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }
        tvSpeedUnit = TextView(this).apply {
            text = "MPH"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            typeface = sansBold
        }
        tvDecimalBtn = makePillButton(".0 OFF", showDecimalSpeed) {
            showDecimalSpeed = !showDecimalSpeed
            savePreferences()
            renderTelemetry()
        }.apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = dp(12) }
        }
        speedUnitRow.addView(tvSpeedUnit)
        speedUnitRow.addView(tvDecimalBtn)

        val speedBottomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        tvMaxSpeed = TextView(this).apply {
            text = "MAX: 0.0 MPH"
            setTextColor(Color.parseColor("#AAAAAA"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = monoBold
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        tvResetMaxBtn = makePillButton("RESET MAX", false) {
            maxSpeedMs = 0.0
            renderTelemetry()
        }
        speedBottomRow.addView(tvMaxSpeed)
        speedBottomRow.addView(tvResetMaxBtn)

        cardSpeed.addView(speedTopRow)
        cardSpeed.addView(tvSpeedDigits)
        cardSpeed.addView(speedUnitRow)
        cardSpeed.addView(speedBottomRow)

        // --- SECONDARY CONTAINER: HEADING & ALTITUDE (SMALLER DIGITS) ---
        secondaryContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        // HEADING CARD
        cardHeading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = makeCardDrawable()
            val pad = dp(14)
            setPadding(pad, dp(12), pad, dp(12))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                cycleHeadingFormat()
            }
        }

        val headingTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val tvHeadingTitle = TextView(this).apply {
            text = "HEADING (COG)"
            setTextColor(Color.parseColor("#888888"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = sansBold
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        tvHeadingFormatBadge = TextView(this).apply {
            text = "DEG + CARD"
            setTextColor(Color.parseColor("#999999"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = monoBold
        }
        headingTopRow.addView(tvHeadingTitle)
        headingTopRow.addView(tvHeadingFormatBadge)

        val headingMiddleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val headingTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        tvHeadingDigits = TextView(this).apply {
            text = "---°"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 38f)
            typeface = monoBold
            includeFontPadding = false
        }
        tvHeadingCardinal = TextView(this).apply {
            text = "--"
            setTextColor(accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = sansBold
        }
        headingTextCol.addView(tvHeadingDigits)
        headingTextCol.addView(tvHeadingCardinal)

        compassView = CompassRoseView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
        }

        headingMiddleRow.addView(headingTextCol)
        headingMiddleRow.addView(compassView)

        tvHeadingSubtext = TextView(this).apply {
            text = "Tap to switch format"
            setTextColor(Color.parseColor("#777777"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = monoBold
        }

        cardHeading.addView(headingTopRow)
        cardHeading.addView(headingMiddleRow)
        cardHeading.addView(tvHeadingSubtext)

        // ALTITUDE CARD
        cardAltitude = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = makeCardDrawable()
            val pad = dp(14)
            setPadding(pad, dp(12), pad, dp(12))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                cycleAltitudeUnit()
            }
        }

        val altTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val tvAltTitle = TextView(this).apply {
            text = "GNSS ALTITUDE"
            setTextColor(Color.parseColor("#888888"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = sansBold
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        tvAltUnitBadge = TextView(this).apply {
            text = "MSL • FT"
            setTextColor(Color.parseColor("#999999"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = monoBold
        }
        altTopRow.addView(tvAltTitle)
        altTopRow.addView(tvAltUnitBadge)

        val altDigitsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        tvAltitudeDigits = TextView(this).apply {
            text = "---"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 38f)
            typeface = monoBold
            includeFontPadding = false
        }
        tvAltitudeUnit = TextView(this).apply {
            text = "FT"
            setTextColor(accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = sansBold
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { leftMargin = dp(8) }
        }
        altDigitsRow.addView(tvAltitudeDigits)
        altDigitsRow.addView(tvAltitudeUnit)

        tvAltitudeMinMax = TextView(this).apply {
            text = "MIN ---  •  MAX ---"
            setTextColor(Color.parseColor("#999999"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = monoBold
        }
        tvAltitudeSubtext = TextView(this).apply {
            text = "Vert Acc: ± --- (Tap for FT/M)"
            setTextColor(Color.parseColor("#777777"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = monoBold
        }

        cardAltitude.addView(altTopRow)
        cardAltitude.addView(altDigitsRow)
        cardAltitude.addView(tvAltitudeMinMax)
        cardAltitude.addView(tvAltitudeSubtext)

        secondaryContainer.addView(cardHeading)
        secondaryContainer.addView(cardAltitude)

        bodyContainer.addView(cardSpeed)
        bodyContainer.addView(secondaryContainer)
        rootContainer.addView(bodyContainer)

        setContentView(rootContainer)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyOrientationLayout(newConfig.orientation)
    }

    private fun applyOrientationLayout(orientation: Int) {
        val gap = dp(10)
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            bodyContainer.orientation = LinearLayout.HORIZONTAL
            cardSpeed.layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.MATCH_PARENT,
                1.35f
            ).apply { rightMargin = gap }

            secondaryContainer.orientation = LinearLayout.VERTICAL
            secondaryContainer.layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.MATCH_PARENT,
                1f
            )

            cardHeading.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply { bottomMargin = gap }

            cardAltitude.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            tvSpeedDigits.setTextSize(TypedValue.COMPLEX_UNIT_SP, 96f)
        } else {
            bodyContainer.orientation = LinearLayout.VERTICAL
            cardSpeed.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.45f
            ).apply { bottomMargin = gap }

            secondaryContainer.orientation = LinearLayout.HORIZONTAL
            secondaryContainer.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )

            cardHeading.layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.MATCH_PARENT,
                1f
            ).apply { rightMargin = gap / 2 }

            cardAltitude.layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.MATCH_PARENT,
                1f
            ).apply { leftMargin = gap / 2 }
            tvSpeedDigits.setTextSize(TypedValue.COMPLEX_UNIT_SP, 118f)
        }
        bodyContainer.requestLayout()
    }

    private fun renderTelemetry() {
        // Status & Satellites
        when {
            demoMode -> {
                tvStatusPill.text = "DEMO GNSS LOCK"
                stylePill(tvStatusPill, true)
            }
            hasGnssFix -> {
                val accStr = horizontalAccM?.let {
                    if (altitudeUnit == AltitudeUnit.FEET) " ±${(it * 3.28084f).roundToInt()}ft"
                    else " ±${it.roundToInt()}m"
                } ?: ""
                tvStatusPill.text = "GNSS 3D LOCK$accStr"
                stylePill(tvStatusPill, true)
            }
            else -> {
                tvStatusPill.text = "GNSS ACQUIRING..."
                stylePill(tvStatusPill, false)
            }
        }

        tvSatsPill.text = "SATS: $satellitesUsed/$satellitesInView"
        tvWakePill.text = if (keepScreenOn) "ALWAYS ON" else "WAKE OFF"
        stylePill(tvWakePill, keepScreenOn)
        stylePill(tvDemoPill, demoMode)
        stylePill(tvHudMirrorPill, mirrorHud)

        // Speed
        val effectiveSpeedMs = if (stationaryFilter && currentSpeedMs < 0.45) 0.0 else currentSpeedMs
        val speedVal = effectiveSpeedMs * speedUnit.factorFromMs
        val maxVal = maxSpeedMs * speedUnit.factorFromMs

        tvSpeedDigits.setTextColor(accentColor)
        tvSpeedDigits.text = if (showDecimalSpeed) {
            String.format("%.1f", speedVal)
        } else {
            speedVal.roundToInt().toString()
        }
        tvSpeedUnit.text = speedUnit.label
        tvDecimalBtn.text = if (showDecimalSpeed) ".0 ON" else ".0 OFF"
        stylePill(tvDecimalBtn, showDecimalSpeed)

        val speedAccText = speedAccuracyMs?.let {
            String.format("  (±%.1f %s)", it * speedUnit.factorFromMs, speedUnit.label)
        } ?: ""
        tvMaxSpeed.text = String.format("MAX: %.1f %s%s", maxVal, speedUnit.label, speedAccText)

        // Heading
        val headingToUse = if (effectiveSpeedMs >= 0.5) {
            currentHeadingDeg ?: lastLockedHeadingDeg
        } else {
            lastLockedHeadingDeg
        }
        val cardinal = degToCardinal(headingToUse)
        tvHeadingFormatBadge.text = headingFormat.badge
        tvHeadingCardinal.setTextColor(accentColor)

        if (headingToUse != null) {
            val degRounded = ((headingToUse.roundToInt() % 360) + 360) % 360
            val degFormatted = String.format("%03d°", degRounded)
            when (headingFormat) {
                HeadingFormat.DEG_AND_CARD -> {
                    tvHeadingDigits.text = degFormatted
                    tvHeadingCardinal.text = cardinal.first
                    tvHeadingCardinal.visibility = View.VISIBLE
                }
                HeadingFormat.DEG_ONLY -> {
                    tvHeadingDigits.text = degFormatted
                    tvHeadingCardinal.visibility = View.GONE
                }
                HeadingFormat.CARD_ONLY -> {
                    tvHeadingDigits.text = cardinal.first
                    tvHeadingCardinal.text = degFormatted
                    tvHeadingCardinal.visibility = View.VISIBLE
                }
            }
            compassView.updateHeading(headingToUse, accentColor)
            tvHeadingSubtext.text = if (effectiveSpeedMs >= 0.5) {
                "${cardinal.second} (Live COG)"
            } else {
                "${cardinal.second} (Last locked)"
            }
        } else {
            tvHeadingDigits.text = "---°"
            tvHeadingCardinal.text = "--"
            tvHeadingCardinal.visibility = View.VISIBLE
            compassView.updateHeading(0f, accentColor)
            tvHeadingSubtext.text = "Move > 1.5 mph for heading"
        }

        // Altitude
        val altRef = if (isMslAltitude) "MSL" else "WGS84"
        tvAltUnitBadge.text = "$altRef • ${altitudeUnit.label}"
        tvAltitudeUnit.text = altitudeUnit.label
        tvAltitudeUnit.setTextColor(accentColor)

        val altM = currentAltitudeM
        if (altM != null) {
            val convertedAlt = (altM * altitudeUnit.factorFromM).roundToInt()
            tvAltitudeDigits.text = String.format("%,d", convertedAlt)
            val minConv = minAltitudeM?.let { (it * altitudeUnit.factorFromM).roundToInt().toString() } ?: "---"
            val maxConv = maxAltitudeM?.let { (it * altitudeUnit.factorFromM).roundToInt().toString() } ?: "---"
            tvAltitudeMinMax.text = "MIN $minConv ${altitudeUnit.label}  •  MAX $maxConv ${altitudeUnit.label}"
        } else {
            tvAltitudeDigits.text = "---"
            tvAltitudeMinMax.text = "MIN ---  •  MAX ---"
        }

        val vAcc = verticalAccM
        tvAltitudeSubtext.text = if (vAcc != null) {
            val vAccConv = (vAcc * altitudeUnit.factorFromM).roundToInt()
            "Vert Acc: ±$vAccConv ${altitudeUnit.label.lowercase()} (Tap for FT/M)"
        } else {
            "Vert Acc: ± --- (Tap for FT/M)"
        }
    }

    // --- GNSS LOCATION MANAGEMENT ---
    private fun ensureLocationPermissionAndStart() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!fineGranted) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                REQ_LOCATION_PERMISSION
            )
        } else {
            startHardwareGnssUpdates()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startHardwareGnssUpdates() {
        if (demoMode) return
        try {
            locationManager.removeUpdates(this)
            // Request maximum-rate 1Hz+ hardware GNSS updates directly from GPS_PROVIDER
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    200L,
                    0f,
                    this,
                    Looper.getMainLooper()
                )
            }
            locationManager.registerGnssStatusCallback(gnssStatusCallback, mainHandler)
        } catch (e: Exception) {
            Toast.makeText(this, "GNSS Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startHardwareGnssUpdates()
            } else {
                Toast.makeText(
                    this,
                    "Precise Location permission is required for GNSS Speedometer.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onLocationChanged(location: Location) {
        if (demoMode) return
        hasGnssFix = true
        horizontalAccM = if (location.hasAccuracy()) location.accuracy else null
        verticalAccM = if (location.hasVerticalAccuracy()) location.verticalAccuracyMeters else null
        speedAccuracyMs = if (location.hasSpeedAccuracy()) location.speedAccuracyMetersPerSecond else null

        // 1. Speed (Direct GNSS Doppler speed preferred, geodesic fallback)
        var rawSpeed = if (location.hasSpeed()) location.speed.toDouble() else -1.0
        if (rawSpeed < 0.0) {
            prevLocation?.let { prev ->
                val dtSec = (location.time - prev.time) / 1000.0
                if (dtSec in 0.2..15.0) {
                    val dist = prev.distanceTo(location).toDouble()
                    if (dist > max(1.5, (location.accuracy * 0.35).toDouble())) {
                        rawSpeed = dist / dtSec
                    }
                }
            }
        }
        currentSpeedMs = max(0.0, rawSpeed)
        val filteredSpeed = if (stationaryFilter && currentSpeedMs < 0.45) 0.0 else currentSpeedMs
        if (filteredSpeed > maxSpeedMs) {
            maxSpeedMs = filteredSpeed
        }

        // 2. Heading (Course Over Ground)
        if (location.hasBearing() && filteredSpeed >= 0.5) {
            currentHeadingDeg = location.bearing
            lastLockedHeadingDeg = currentHeadingDeg
        } else if (filteredSpeed >= 0.5 && prevLocation != null) {
            val brng = (prevLocation!!.bearingTo(location) + 360f) % 360f
            currentHeadingDeg = brng
            lastLockedHeadingDeg = brng
        } else if (filteredSpeed < 0.5) {
            currentHeadingDeg = null
        }

        // 3. Altitude (Prefer Android 14+ Mean Sea Level altitude on Pixel 9 Pro XL)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && location.hasMslAltitude()) {
            currentAltitudeM = location.mslAltitudeMeters
            isMslAltitude = true
            if (location.hasMslAltitudeAccuracy()) {
                verticalAccM = location.mslAltitudeAccuracyMeters
            }
        } else if (location.hasAltitude()) {
            currentAltitudeM = location.altitude
            isMslAltitude = false
        }

        currentAltitudeM?.let { alt ->
            minAltitudeM = minAltitudeM?.let { minOf(it, alt) } ?: alt
            maxAltitudeM = maxAltitudeM?.let { maxOf(it, alt) } ?: alt
        }

        prevLocation = location
        renderTelemetry()
    }

    private fun toggleDemoMode(enable: Boolean) {
        demoMode = enable
        if (demoMode) {
            locationManager.removeUpdates(this)
            mainHandler.removeCallbacks(demoRunnable)
            mainHandler.post(demoRunnable)
            Toast.makeText(this, "Demo GNSS Simulator ON", Toast.LENGTH_SHORT).show()
        } else {
            mainHandler.removeCallbacks(demoRunnable)
            currentSpeedMs = 0.0
            maxSpeedMs = 0.0
            currentHeadingDeg = null
            lastLockedHeadingDeg = null
            currentAltitudeM = null
            minAltitudeM = null
            maxAltitudeM = null
            hasGnssFix = false
            renderTelemetry()
            ensureLocationPermissionAndStart()
            Toast.makeText(this, "Live Hardware GNSS Active", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cycleSpeedUnit() {
        val values = SpeedUnit.values()
        speedUnit = values[(speedUnit.ordinal + 1) % values.size]
        savePreferences()
        renderTelemetry()
    }

    private fun cycleAltitudeUnit() {
        altitudeUnit = if (altitudeUnit == AltitudeUnit.FEET) AltitudeUnit.METERS else AltitudeUnit.FEET
        savePreferences()
        renderTelemetry()
    }

    private fun cycleHeadingFormat() {
        val values = HeadingFormat.values()
        headingFormat = values[(headingFormat.ordinal + 1) % values.size]
        savePreferences()
        renderTelemetry()
    }

    private fun showSettingsDialog() {
        val items = arrayOf(
            "Speed Unit: ${speedUnit.label} (Tap to cycle)",
            "Altitude Unit: ${altitudeUnit.label} (Tap to toggle)",
            "Heading Format: ${headingFormat.badge} (Tap to cycle)",
            "OLED Accent: Emerald Green (#00FF66)",
            "OLED Accent: Cyber Cyan (#00E5FF)",
            "OLED Accent: Tactical Amber (#FFB300)",
            "OLED Accent: Night Red (#FF3333)",
            "OLED Accent: Pure White (#FFFFFF)",
            "Stationary Drift Filter (<0.5 m/s): ${if (stationaryFilter) "ON" else "OFF"}"
        )

        AlertDialog.Builder(this)
            .setTitle("Pixel 9 Pro XL GNSS HUD Settings")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> cycleSpeedUnit()
                    1 -> cycleAltitudeUnit()
                    2 -> cycleHeadingFormat()
                    3 -> updateAccentColor("#00FF66")
                    4 -> updateAccentColor("#00E5FF")
                    5 -> updateAccentColor("#FFB300")
                    6 -> updateAccentColor("#FF3333")
                    7 -> updateAccentColor("#FFFFFF")
                    8 -> {
                        stationaryFilter = !stationaryFilter
                        savePreferences()
                        renderTelemetry()
                    }
                }
            }
            .setPositiveButton("Close", null)
            .show()
    }

    private fun updateAccentColor(hex: String) {
        accentColor = Color.parseColor(hex)
        savePreferences()
        renderTelemetry()
    }

    private fun degToCardinal(deg: Float?): Pair<String, String> {
        if (deg == null || deg.isNaN()) return "--" to "True North Ref"
        val dirs = arrayOf(
            "N" to "North", "NNE" to "North-Northeast", "NE" to "Northeast", "ENE" to "East-Northeast",
            "E" to "East", "ESE" to "East-Southeast", "SE" to "Southeast", "SSE" to "South-Southeast",
            "S" to "South", "SSW" to "South-Southwest", "SW" to "Southwest", "WSW" to "West-Southwest",
            "W" to "West", "WNW" to "West-Northwest", "NW" to "Northwest", "NNW" to "North-Northwest"
        )
        val norm = ((deg % 360f) + 360f) % 360f
        val idx = ((norm / 22.5f).roundToInt()) % 16
        return dirs[idx]
    }

    private fun loadPreferences() {
        speedUnit = SpeedUnit.valueOf(prefs.getString("speedUnit", SpeedUnit.MPH.name) ?: SpeedUnit.MPH.name)
        altitudeUnit = AltitudeUnit.valueOf(prefs.getString("altUnit", AltitudeUnit.FEET.name) ?: AltitudeUnit.FEET.name)
        headingFormat = HeadingFormat.valueOf(prefs.getString("headingFormat", HeadingFormat.DEG_AND_CARD.name) ?: HeadingFormat.DEG_AND_CARD.name)
        showDecimalSpeed = prefs.getBoolean("showDecimalSpeed", false)
        stationaryFilter = prefs.getBoolean("stationaryFilter", true)
        keepScreenOn = prefs.getBoolean("keepScreenOn", true)
        accentColor = prefs.getInt("accentColor", Color.parseColor("#00FF66"))
    }

    private fun savePreferences() {
        prefs.edit()
            .putString("speedUnit", speedUnit.name)
            .putString("altUnit", altitudeUnit.name)
            .putString("headingFormat", headingFormat.name)
            .putBoolean("showDecimalSpeed", showDecimalSpeed)
            .putBoolean("stationaryFilter", stationaryFilter)
            .putBoolean("keepScreenOn", keepScreenOn)
            .putInt("accentColor", accentColor)
            .apply()
    }

    override fun onResume() {
        super.onResume()
        configureWindow()
        if (!demoMode && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            startHardwareGnssUpdates()
        }
    }

    override fun onPause() {
        super.onPause()
        if (!demoMode) {
            locationManager.removeUpdates(this)
            locationManager.unregisterGnssStatusCallback(gnssStatusCallback)
        }
    }

    // --- UI HELPERS ---
    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).roundToInt()

    private fun pillMargin(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { rightMargin = dp(6) }

    private fun makeCardDrawable(): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(24).toFloat()
            setColor(Color.parseColor("#060606"))
            setStroke(dp(1), Color.parseColor("#1F1F1F"))
        }

    private fun makePillButton(text: String, active: Boolean, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            isClickable = true
            isFocusable = true
            stylePill(this, active)
            setOnClickListener { onClick() }
        }
    }

    private fun stylePill(view: TextView, active: Boolean) {
        view.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(999).toFloat()
            if (active) {
                setColor(Color.argb(40, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)))
                setStroke(dp(1), accentColor)
            } else {
                setColor(Color.parseColor("#0A0A0A"))
                setStroke(dp(1), Color.parseColor("#262626"))
            }
        }
        view.setTextColor(if (active) accentColor else Color.parseColor("#CCCCCC"))
    }

    // Custom OLED Vector Compass Rose View
    class CompassRoseView(context: Context) : View(context) {
        private var headingDeg: Float = 0f
        private var arrowColor: Int = Color.parseColor("#00FF66")

        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = Color.parseColor("#262626")
        }
        private val northPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = arrowColor
        }
        private val southPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#333333")
        }
        private val arrowPath = Path()

        fun updateHeading(deg: Float, color: Int) {
            headingDeg = deg
            arrowColor = color
            northPaint.color = color
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val radius = (minOf(width, height) / 2f) - 4f

            canvas.drawCircle(cx, cy, radius, ringPaint)

            canvas.save()
            canvas.rotate(headingDeg, cx, cy)

            // North pointer
            arrowPath.reset()
            arrowPath.moveTo(cx, cy - radius * 0.78f)
            arrowPath.lineTo(cx + radius * 0.26f, cy + radius * 0.1f)
            arrowPath.lineTo(cx - radius * 0.26f, cy + radius * 0.1f)
            arrowPath.close()
            canvas.drawPath(arrowPath, northPaint)

            // South tail
            arrowPath.reset()
            arrowPath.moveTo(cx, cy + radius * 0.72f)
            arrowPath.lineTo(cx - radius * 0.24f, cy + radius * 0.1f)
            arrowPath.lineTo(cx + radius * 0.24f, cy + radius * 0.1f)
            arrowPath.close()
            canvas.drawPath(arrowPath, southPaint)

            canvas.restore()
        }
    }
}
